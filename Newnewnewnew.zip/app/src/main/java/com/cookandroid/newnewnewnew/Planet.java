package com.cookandroid.newnewnewnew;

public class Planet{

    String StartDate;
    String dajim;
    String keyword;
    String planetName;



    public Planet(){

    }

    public String getStartDate() {
        return StartDate;
    }

    public void setStartDate(String startDate) {
        StartDate = startDate;
    }

    public String getDajim() {
        return dajim;
    }

    public void setDajim(String dajim) {
        this.dajim = dajim;
    }

    public String getKeyword() {
        return keyword;
    }

    public void setKeyword(String keyword) {
        this.keyword = keyword;
    }

    public String getPlanetName() {
        return planetName;
    }

    public void setPlanetName(String planetName) {
        this.planetName = planetName;
    }
}
